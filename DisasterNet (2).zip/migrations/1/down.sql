
DROP INDEX idx_disaster_reports_created_at;
DROP INDEX idx_disaster_reports_severity;
DROP INDEX idx_disaster_reports_category;
DROP TABLE disaster_reports;

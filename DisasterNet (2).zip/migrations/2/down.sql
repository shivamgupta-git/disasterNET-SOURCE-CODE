
DROP INDEX idx_sos_requests_created_at;
DROP INDEX idx_sos_requests_status;
DROP INDEX idx_sos_requests_priority;
DROP TABLE sos_requests;
